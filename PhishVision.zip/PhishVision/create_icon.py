#!/usr/bin/env python3
"""
Create a simple icon for PhishVision extension
"""

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    print("Installing Pillow...")
    import subprocess
    subprocess.check_call(["pip", "install", "pillow"])
    from PIL import Image, ImageDraw, ImageFont

def create_icon():
    # Create a 128x128 image with transparent background
    img = Image.new('RGBA', (128, 128), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Draw gradient background (simplified as solid color)
    draw.rectangle([0, 0, 128, 128], fill=(102, 126, 234, 255))
    
    # Draw shield shape
    shield_points = [
        (64, 20),   # top
        (45, 30),   # left top
        (45, 70),   # left bottom
        (64, 100),  # bottom
        (83, 70),   # right bottom
        (83, 30),   # right top
    ]
    draw.polygon(shield_points, fill=(255, 255, 255, 255))
    
    # Draw eye (simplified)
    draw.ellipse([49, 40, 79, 60], fill=(102, 126, 234, 255))
    draw.ellipse([58, 44, 70, 56], fill=(255, 255, 255, 255))
    
    # Try to add text
    try:
        # Use default font
        font = ImageFont.load_default()
        draw.text((64, 110), "PHISH", fill=(255, 255, 255, 255), anchor="mm", font=font)
    except:
        # If font fails, just use simple text
        draw.text((50, 110), "PHISH", fill=(255, 255, 255, 255))
    
    # Save different sizes
    sizes = [16, 48, 128]
    for size in sizes:
        if size != 128:
            resized = img.resize((size, size), Image.Resampling.LANCZOS)
            resized.save(f'extension/icon_{size}.png')
        else:
            img.save('extension/icon.png')
    
    print("✅ Icons created successfully!")
    print("   - extension/icon.png (128x128)")
    print("   - extension/icon_16.png (16x16)")
    print("   - extension/icon_48.png (48x48)")

if __name__ == "__main__":
    create_icon()