# 🚀 PhishVision Quick Installation Guide

## Prerequisites
- Python 3.7+ installed
- Google Chrome browser
- Command line access

## Step 1: Install Dependencies

```bash
# Install required Python packages
pip install flask flask-cors
```

## Step 2: Start the Backend

### Option A: Using the provided script (Recommended)
1. Double-click `start_backend.bat` (Windows)
2. Or run in terminal: `./start_backend.bat`

### Option B: Manual startup
```bash
cd backend
python app.py
```

**You should see:**
```
🔍 PhishVision Backend Starting...
🌐 Server running on http://127.0.0.1:5000
📡 Ready to analyze URLs for phishing detection
```

## Step 3: Install Chrome Extension

1. Open Chrome and navigate to: `chrome://extensions/`
2. Enable "Developer mode" (toggle in top-right)
3. Click "Load unpacked"
4. Select the `extension/` folder from this project
5. The PhishVision extension should appear in your toolbar

## Step 4: Verify Installation

1. **Test Backend**: Run `python test_backend.py`
2. **Test Extension**: Click the PhishVision icon - should show "✅ Backend Connected"
3. **Test Detection**: Visit any website and check browser console for extension logs

## Step 5: Test Phishing Detection

Try visiting these test URLs (safe testing):
- `https://secure-login-verification.test.com/urgent-account-update` (should trigger alert)
- `https://www.google.com` (should be safe)

## Troubleshooting

### Backend Issues
- **Port in use**: Change port in `backend/app.py`
- **Module not found**: Run `pip install flask flask-cors`

### Extension Issues
- **Backend offline**: Make sure Flask server is running
- **No notifications**: Check Chrome notification permissions
- **Extension not loading**: Verify all files are in `extension/` folder

## File Structure
```
PhishVision/
├── extension/              # Chrome Extension
│   ├── manifest.json
│   ├── background.js
│   ├── content.js
│   ├── popup.html
│   ├── popup.js
│   ├── style.css
│   └── icon*.png
├── backend/
│   └── app.py             # Flask backend
├── start_backend.bat      # Windows startup script
├── test_backend.py        # Test script
└── README.md             # Full documentation
```

## Success Indicators
- ✅ Backend shows "Server running on http://127.0.0.1:5000"
- ✅ Extension popup shows "Backend Connected"
- ✅ Chrome notifications appear for suspicious URLs
- ✅ Test script passes all checks

**You're ready to browse safely! 🛡️**