import requests

url_to_test = "http://secure-login.example.com"

response = requests.post("http://127.0.0.1:5000/predict", json={"url": url_to_test})

print("Response status code:", response.status_code)
print("Response JSON:", response.json())
