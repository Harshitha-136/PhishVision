from urllib.parse import urlparse
import re
import logging

logger = logging.getLogger(__name__)

def extract_features(url):
    """
    Extract features from a URL for phishing detection.
    
    Args:
        url (str): URL to analyze
        
    Returns:
        dict: Dictionary containing extracted features
    """
    if not url or not isinstance(url, str):
        raise ValueError("URL must be a non-empty string")
    
    # Clean the URL
    url = url.strip()
    
    try:
        # Parse URL for better analysis
        parsed = urlparse(url)
        
        # Feature 1: URL length
        url_length = len(url)
        
        # Feature 2: Has HTTPS
        has_https = int(parsed.scheme.lower() == 'https')
        
        # Feature 3: Has HTTP redirect indicators
        # Check for suspicious patterns that might indicate HTTP to HTTPS redirects
        has_http = int(
            'http://' in url.lower() or 
            parsed.scheme.lower() == 'http' or
            bool(re.search(r'redirect.*http', url.lower()))
        )
        
        # Feature 4: Has @ symbol (often used in phishing to confuse users)
        has_at_symbol = int('@' in url)
        
        # Feature 5: Has many dots (suspicious domain structure)
        has_many_dots = int(url.count('.') > 3)
        
        # Feature 6: Has suspicious words
        suspicious_words = [
            'secure', 'login', 'bank', 'paypal', 'amazon', 'microsoft',
            'apple', 'google', 'verify', 'account', 'update', 'confirm',
            'suspended', 'limited', 'locked', 'security', 'alert'
        ]
        has_suspicious_word = int(any(word in url.lower() for word in suspicious_words))
        
        # Return features as dictionary for better readability
        features = {
            'url_length': url_length,
            'has_https': has_https,
            'has_http': has_http,
            'has_at_symbol': has_at_symbol,
            'has_many_dots': has_many_dots,
            'has_suspicious_word': has_suspicious_word
        }
        
        logger.debug(f"Features extracted for URL: {url[:50]}... -> {features}")
        return features
        
    except Exception as e:
        logger.error(f"Error extracting features from URL '{url}': {e}")
        raise ValueError(f"Failed to extract features: {e}")

def extract_features_list(url):
    """
    Extract features and return as a list (for backward compatibility).
    
    Args:
        url (str): URL to analyze
        
    Returns:
        list: List of feature values in the expected order
    """
    features_dict = extract_features(url)
    return [
        features_dict['url_length'],
        features_dict['has_https'],
        features_dict['has_http'],
        features_dict['has_at_symbol'],
        features_dict['has_many_dots'],
        features_dict['has_suspicious_word']
    ]

def batch_extract_features(urls):
    """
    Extract features from multiple URLs.
    
    Args:
        urls (list): List of URLs to analyze
        
    Returns:
        list: List of feature dictionaries
    """
    if not urls:
        return []
    
    features_list = []
    for i, url in enumerate(urls):
        try:
            features = extract_features(url)
            features_list.append(features)
        except Exception as e:
            logger.warning(f"Skipping URL {i+1} due to error: {e}")
            continue
    
    return features_list
