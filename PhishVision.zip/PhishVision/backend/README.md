# PhishVision Backend

A robust Flask-based API for phishing URL detection using machine learning.

## Features

- **Comprehensive Error Handling**: Professional error messages with actionable guidance
- **Automated Dataset Generation**: Creates synthetic phishing datasets for training
- **Model Training with Validation**: Trains RandomForest classifier with performance metrics
- **RESTful API**: Clean endpoints for prediction and system health
- **Robust Input Validation**: Validates all inputs with detailed error messages
- **Logging System**: Comprehensive logging for debugging and monitoring

## Quick Start

### Option 1: Automatic Setup (Recommended)
```bash
cd backend
python run_phishvision.py
```

### Option 2: Manual Setup
```bash
cd backend

# Step 1: Generate dataset
python generate_dataset.py

# Step 2: Train model
python train_model.py

# Step 3: Run tests (optional)
python simple_test.py

# Step 4: Start API
python app.py
```

## API Endpoints

### 🏥 Health Check
```
GET /health
```
Returns the service health status and model availability.

**Response:**
```json
{
  "status": "healthy",
  "message": "PhishVision API is running",
  "model_loaded": true,
  "required_features": ["url_length", "has_https", "has_http", "has_at_symbol", "has_many_dots", "has_suspicious_word"]
}
```

### 🔍 Predict Phishing
```
POST /predict
```
Predicts whether a URL is phishing based on extracted features.

**Request Body:**
```json
{
  "url_length": 50,
  "has_https": 1,
  "has_http": 0,
  "has_at_symbol": 0,
  "has_many_dots": 0,
  "has_suspicious_word": 1
}
```

**Response:**
```json
{
  "prediction": "Phishing",
  "confidence": 0.8234,
  "risk_score": 0.8234,
  "features_used": ["url_length", "has_https", "has_http", "has_at_symbol", "has_many_dots", "has_suspicious_word"]
}
```

### 📋 Get Features
```
GET /features
```
Returns the list of required features and their descriptions.

**Response:**
```json
{
  "required_features": ["url_length", "has_https", "has_http", "has_at_symbol", "has_many_dots", "has_suspicious_word"],
  "feature_descriptions": {
    "url_length": "Length of the URL in characters (positive integer)",
    "has_https": "Whether URL uses HTTPS (0 or 1)",
    "has_http": "Whether URL has HTTP redirect (0 or 1)",
    "has_at_symbol": "Whether URL contains @ symbol (0 or 1)",
    "has_many_dots": "Whether URL has many dots (0 or 1)",
    "has_suspicious_word": "Whether URL contains suspicious words (0 or 1)"
  }
}
```

## Feature Extraction

The `feature_extraction.py` module provides functions to extract features from URLs:

```python
from feature_extraction import extract_features

# Extract features from a URL
features = extract_features("https://secure-bank-login.suspicious-domain.com/@phishing.html")
print(features)
# Output: {'url_length': 62, 'has_https': 1, 'has_http': 0, 'has_at_symbol': 1, 'has_many_dots': 0, 'has_suspicious_word': 1}
```

## Error Handling

The system provides comprehensive error handling with specific, actionable error messages:

### File Not Found Errors
- **Dataset Missing**: Guides user to run `generate_dataset.py`
- **Model Missing**: Guides user to run `train_model.py`

### Validation Errors
- **Missing Features**: Lists exactly which features are missing
- **Invalid Feature Values**: Explains valid ranges and types
- **Malformed Requests**: Provides clear formatting guidance

### Example Error Response
```json
{
  "error": "Input validation failed",
  "details": "Missing required features: ['url_length', 'has_https']",
  "required_features": ["url_length", "has_https", "has_http", "has_at_symbol", "has_many_dots", "has_suspicious_word"]
}
```

## Files Overview

| File | Purpose |
|------|---------|
| `generate_dataset.py` | Creates synthetic phishing dataset |
| `train_model.py` | Trains RandomForest classifier |
| `app.py` | Flask API server |
| `feature_extraction.py` | URL feature extraction utilities |
| `simple_test.py` | System testing script |
| `run_phishvision.py` | Automated setup script |

## Model Performance

The RandomForest classifier is trained with:
- **100 estimators** for robust predictions
- **Train/validation split** (80/20) for performance evaluation
- **Stratified sampling** to maintain class balance
- **Accuracy reporting** with detailed classification metrics

## Dependencies

```
pandas>=1.3.0
scikit-learn>=1.0.0
joblib>=1.0.0
flask>=2.0.0
```

## Logging

The system uses comprehensive logging:
- **INFO level**: Normal operations and progress
- **WARNING level**: Non-critical issues
- **ERROR level**: Critical errors with guidance

## Testing

Run the test suite to verify everything works:
```bash
python simple_test.py
```

The test suite validates:
- ✅ Module imports
- ✅ Feature extraction
- ✅ Required files exist
- ✅ Model loading and prediction
- ✅ Flask app initialization

## Troubleshooting

### Common Issues

1. **"Model not found"**
   - Run `python train_model.py` to create the model

2. **"Dataset not found"**
   - Run `python generate_dataset.py` to create the dataset

3. **"Import errors"**
   - Install dependencies: `pip install pandas scikit-learn joblib flask`

4. **"Permission denied"**
   - Check file permissions in the working directory

### Debug Mode

The Flask app runs in debug mode by default. To disable:
```python
app.run(host='0.0.0.0', port=5000, debug=False)
```

## Production Deployment

For production deployment:

1. **Disable debug mode**
2. **Use a production WSGI server** (e.g., Gunicorn)
3. **Set up proper logging**
4. **Configure environment variables**
5. **Add authentication if needed**

Example with Gunicorn:
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

## Contributing

1. Follow the existing error handling patterns
2. Add comprehensive logging for new features
3. Include user-friendly error messages
4. Update tests when adding new functionality
5. Maintain backward compatibility for API endpoints