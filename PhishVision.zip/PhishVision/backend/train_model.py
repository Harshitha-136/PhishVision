import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import joblib
import os
import logging

# Set up logging for better user guidance
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def train_phishing_model():
    """
    Train a RandomForest model for phishing detection with comprehensive error handling.
    """
    try:
        # Check if the dataset exists with helpful error message
        dataset_path = 'phishing_dataset.csv'
        if not os.path.exists(dataset_path):
            error_msg = (
                f"Dataset file '{dataset_path}' not found in the current directory.\n"
                "Please follow these steps:\n"
                "1. Run 'python generate_dataset.py' to create the dataset\n"
                "2. Or place your own dataset with the required columns in the same directory"
            )
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)
        
        logger.info(f"Loading dataset from {dataset_path}...")
        df = pd.read_csv(dataset_path)
        
        # Validate dataset is not empty
        if df.empty:
            raise ValueError("The dataset is empty. Please generate a valid dataset using 'generate_dataset.py'.")
        
        # Check if the required columns are present
        required_columns = ["url_length", "has_https", "has_http", "has_at_symbol", "has_many_dots", "has_suspicious_word", "label"]
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            error_msg = (
                f"Missing required columns: {missing_columns}\n"
                f"Expected columns: {required_columns}\n"
                f"Found columns: {list(df.columns)}\n"
                "Please regenerate the dataset using 'generate_dataset.py' or ensure your dataset has the correct format."
            )
            logger.error(error_msg)
            raise ValueError(error_msg)
        
        # Validate label column contains expected values
        unique_labels = df['label'].unique()
        if not all(label in [0, 1] for label in unique_labels):
            logger.warning(f"Label column contains unexpected values: {unique_labels}. Expected: [0, 1]")
        
        logger.info(f"Dataset loaded successfully. Shape: {df.shape}")
        logger.info(f"Label distribution: {df['label'].value_counts().to_dict()}")
        
        # Prepare features and target
        X = df.drop(columns=['label'])
        y = df['label']
        
        # Split data for validation
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
        
        # Train the model
        logger.info("Training RandomForest model...")
        model = RandomForestClassifier(n_estimators=100, random_state=42)
        model.fit(X_train, y_train)
        
        # Evaluate the model
        y_pred = model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        
        logger.info(f"Model training completed. Accuracy: {accuracy:.4f}")
        logger.info("Classification Report:")
        print(classification_report(y_test, y_pred))
        
        # Save the model
        model_path = 'phishing_model.pkl'
        joblib.dump(model, model_path)
        logger.info(f"Model saved successfully to {model_path}")
        
        # Log feature names for reference
        logger.info(f"Feature names: {list(X.columns)}")
        
        return model
        
    except FileNotFoundError as e:
        logger.error(f"File not found: {e}")
        raise
    except pd.errors.EmptyDataError:
        error_msg = "The dataset file is empty or corrupted. Please regenerate using 'generate_dataset.py'."
        logger.error(error_msg)
        raise ValueError(error_msg)
    except Exception as e:
        logger.error(f"Unexpected error during model training: {e}")
        raise

if __name__ == "__main__":
    try:
        train_phishing_model()
        print("\n✅ Model training completed successfully!")
        print("You can now run the Flask app using 'python app.py'")
    except Exception as e:
        print(f"\n❌ Model training failed: {e}")
        exit(1)
