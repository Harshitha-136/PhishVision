import pandas as pd
import random
import os
import logging

# Set up logging for better user guidance
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def generate_data(n=100):
    """
    Generate synthetic phishing dataset with realistic feature distributions.
    
    Args:
        n (int): Number of samples to generate
        
    Returns:
        pd.DataFrame: Generated dataset with phishing features
    """
    if n <= 0:
        raise ValueError("Number of samples must be positive")
    
    logger.info(f"Generating {n} samples of phishing data...")
    
    data = []
    for i in range(n):
        # Generate features with realistic distributions
        url_length = random.randint(10, 150)  # Expanded range for more realistic URLs
        has_https = random.choices([0, 1], weights=[0.3, 0.7])[0]  # More HTTPS in modern web
        has_http = random.choices([0, 1], weights=[0.8, 0.2])[0]   # Less HTTP redirects
        has_at_symbol = random.choices([0, 1], weights=[0.9, 0.1])[0]  # @ symbol is rare
        has_many_dots = random.choices([0, 1], weights=[0.7, 0.3])[0]  # Many dots are suspicious
        has_suspicious_word = random.choices([0, 1], weights=[0.8, 0.2])[0]  # Suspicious words are less common
        
        # Improved labeling logic: phishing if it has suspicious characteristics
        # Higher weight for more suspicious features
        suspicious_score = (
            (has_http * 1.5) +           # HTTP redirect is more suspicious
            (has_at_symbol * 2) +        # @ symbol is highly suspicious
            (has_many_dots * 1.2) +      # Many dots are suspicious
            (has_suspicious_word * 1.8) + # Suspicious words are highly indicative
            (1 if url_length > 100 else 0)  # Very long URLs are suspicious
        )
        
        # Label as phishing if suspicious score >= 2
        label = int(suspicious_score >= 2)
        
        row = [url_length, has_https, has_http, has_at_symbol, has_many_dots, has_suspicious_word, label]
        data.append(row)
        
        # Progress indicator for large datasets
        if (i + 1) % 100 == 0:
            logger.info(f"Generated {i + 1}/{n} samples...")
    
    df = pd.DataFrame(data, columns=[
        "url_length", "has_https", "has_http", "has_at_symbol", "has_many_dots", "has_suspicious_word", "label"
    ])
    
    # Log dataset statistics
    logger.info(f"Dataset generation completed!")
    logger.info(f"Total samples: {len(df)}")
    logger.info(f"Phishing samples: {df['label'].sum()}")
    logger.info(f"Legitimate samples: {len(df) - df['label'].sum()}")
    logger.info(f"Phishing ratio: {df['label'].mean():.2%}")
    
    return df

def save_dataset(df, filename="phishing_dataset.csv"):
    """
    Save the dataset to CSV with error handling.
    
    Args:
        df (pd.DataFrame): Dataset to save
        filename (str): Output filename
    """
    try:
        # Check if file already exists and warn user
        if os.path.exists(filename):
            logger.warning(f"File '{filename}' already exists and will be overwritten.")
        
        df.to_csv(filename, index=False)
        logger.info(f"Dataset saved successfully to '{filename}'")
        
        # Verify the file was created and is readable
        if os.path.exists(filename):
            file_size = os.path.getsize(filename)
            logger.info(f"File size: {file_size} bytes")
        else:
            raise IOError(f"Failed to create file '{filename}'")
            
    except PermissionError:
        error_msg = f"Permission denied: Cannot write to '{filename}'. Check file permissions."
        logger.error(error_msg)
        raise PermissionError(error_msg)
    except Exception as e:
        error_msg = f"Failed to save dataset: {e}"
        logger.error(error_msg)
        raise

def main():
    """
    Main function to generate and save the phishing dataset.
    """
    try:
        # Generate dataset with more samples for better model training
        df = generate_data(1000)
        
        # Validate dataset before saving
        if df.empty:
            raise ValueError("Generated dataset is empty")
        
        # Save the dataset
        save_dataset(df, "phishing_dataset.csv")
        
        print("\n✅ Dataset generation completed successfully!")
        print("You can now run 'python train_model.py' to train the model.")
        
    except Exception as e:
        print(f"\n❌ Dataset generation failed: {e}")
        exit(1)

if __name__ == "__main__":
    main()
