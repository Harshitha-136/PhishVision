#!/usr/bin/env python3
"""
Test script to verify all components of the PhishVision system work together.
"""

import requests
import json
import time
import subprocess
import os
import logging
from feature_extraction import extract_features

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_feature_extraction():
    """Test the feature extraction module."""
    print("\n🔍 Testing Feature Extraction...")
    
    test_urls = [
        "https://google.com",
        "http://secure-bank-login.suspicious-domain.com/@phishing.html",
        "https://paypal-verify-account-security.com",
        "https://amazon.com/products"
    ]
    
    for url in test_urls:
        try:
            features = extract_features(url)
            print(f"✅ {url[:50]}... -> {features}")
        except Exception as e:
            print(f"❌ Error processing {url}: {e}")
    
    print("✅ Feature extraction test completed")

def test_flask_api():
    """Test the Flask API endpoints."""
    print("\n🌐 Testing Flask API...")
    
    base_url = "http://localhost:5000"
    
    # Test data
    test_cases = [
        {
            "name": "Legitimate URL",
            "data": {
                "url_length": 20,
                "has_https": 1,
                "has_http": 0,
                "has_at_symbol": 0,
                "has_many_dots": 0,
                "has_suspicious_word": 0
            }
        },
        {
            "name": "Phishing URL",
            "data": {
                "url_length": 80,
                "has_https": 0,
                "has_http": 1,
                "has_at_symbol": 1,
                "has_many_dots": 1,
                "has_suspicious_word": 1
            }
        }
    ]
    
    try:
        # Test health endpoint
        response = requests.get(f"{base_url}/health", timeout=5)
        if response.status_code == 200:
            print("✅ Health endpoint working")
        else:
            print(f"❌ Health endpoint failed: {response.status_code}")
        
        # Test features endpoint
        response = requests.get(f"{base_url}/features", timeout=5)
        if response.status_code == 200:
            print("✅ Features endpoint working")
        else:
            print(f"❌ Features endpoint failed: {response.status_code}")
        
        # Test prediction endpoint
        for test_case in test_cases:
            response = requests.post(
                f"{base_url}/predict",
                json=test_case["data"],
                timeout=5
            )
            if response.status_code == 200:
                result = response.json()
                print(f"✅ {test_case['name']}: {result['prediction']} (confidence: {result.get('confidence', 'N/A')})")
            else:
                print(f"❌ {test_case['name']} failed: {response.status_code}")
    
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to Flask API. Make sure the server is running.")
    except Exception as e:
        print(f"❌ API test failed: {e}")

def test_error_handling():
    """Test error handling scenarios."""
    print("\n🚨 Testing Error Handling...")
    
    base_url = "http://localhost:5000"
    
    # Test invalid data
    invalid_cases = [
        {"name": "Empty request", "data": {}},
        {"name": "Missing features", "data": {"url_length": 50}},
        {"name": "Invalid feature values", "data": {
            "url_length": -1,
            "has_https": 2,
            "has_http": "invalid",
            "has_at_symbol": 1,
            "has_many_dots": 1,
            "has_suspicious_word": 1
        }}
    ]
    
    try:
        for case in invalid_cases:
            response = requests.post(
                f"{base_url}/predict",
                json=case["data"],
                timeout=5
            )
            if response.status_code == 400:
                print(f"✅ {case['name']}: Correctly rejected with 400")
            else:
                print(f"❌ {case['name']}: Expected 400, got {response.status_code}")
    
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to Flask API for error testing.")
    except Exception as e:
        print(f"❌ Error handling test failed: {e}")

def main():
    """Run all tests."""
    print("🔧 PhishVision System Test Suite")
    print("=" * 50)
    
    # Test feature extraction
    test_feature_extraction()
    
    # Check if Flask server is running
    print("\n🚀 Checking Flask API availability...")
    try:
        response = requests.get("http://localhost:5000/health", timeout=2)
        if response.status_code == 200:
            test_flask_api()
            test_error_handling()
        else:
            print("❌ Flask API not responding correctly")
    except requests.exceptions.ConnectionError:
        print("⚠️  Flask API not running. To test the API:")
        print("1. Run 'python app.py' in another terminal")
        print("2. Wait for the server to start")
        print("3. Run this test script again")
    
    print("\n✅ System test completed!")
    print("\nTo run the complete system:")
    print("1. python generate_dataset.py")
    print("2. python train_model.py")
    print("3. python app.py")

if __name__ == "__main__":
    main()