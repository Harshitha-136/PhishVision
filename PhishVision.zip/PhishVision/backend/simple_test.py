#!/usr/bin/env python3
"""
Simple test script to verify core components work without external dependencies.
"""

import os
import sys
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_imports():
    """Test that all modules can be imported successfully."""
    print("🔍 Testing module imports...")
    
    try:
        import pandas as pd
        print("✅ pandas imported successfully")
    except ImportError as e:
        print(f"❌ pandas import failed: {e}")
        return False
    
    try:
        from sklearn.ensemble import RandomForestClassifier
        print("✅ sklearn imported successfully")
    except ImportError as e:
        print(f"❌ sklearn import failed: {e}")
        return False
    
    try:
        import joblib
        print("✅ joblib imported successfully")
    except ImportError as e:
        print(f"❌ joblib import failed: {e}")
        return False
    
    try:
        from flask import Flask
        print("✅ Flask imported successfully")
    except ImportError as e:
        print(f"❌ Flask import failed: {e}")
        return False
    
    return True

def test_feature_extraction():
    """Test the feature extraction module."""
    print("\n🔍 Testing Feature Extraction...")
    
    try:
        from feature_extraction import extract_features
        
        test_urls = [
            "https://google.com",
            "http://secure-bank-login.suspicious-domain.com/@phishing.html",
            "https://paypal-verify-account-security.com",
            "https://amazon.com/products"
        ]
        
        for url in test_urls:
            try:
                features = extract_features(url)
                print(f"✅ {url[:40]}... -> {features}")
            except Exception as e:
                print(f"❌ Error processing {url}: {e}")
                return False
        
        print("✅ Feature extraction test completed successfully")
        return True
        
    except ImportError as e:
        print(f"❌ Cannot import feature_extraction: {e}")
        return False

def test_model_files():
    """Test that required files exist."""
    print("\n📁 Testing file existence...")
    
    files_to_check = [
        "phishing_dataset.csv",
        "phishing_model.pkl"
    ]
    
    all_exist = True
    for file_name in files_to_check:
        if os.path.exists(file_name):
            size = os.path.getsize(file_name)
            print(f"✅ {file_name} exists ({size} bytes)")
        else:
            print(f"❌ {file_name} not found")
            all_exist = False
    
    return all_exist

def test_model_loading():
    """Test that the model can be loaded and used."""
    print("\n🤖 Testing model loading...")
    
    try:
        import joblib
        import pandas as pd
        
        if not os.path.exists("phishing_model.pkl"):
            print("❌ Model file not found")
            return False
        
        model = joblib.load("phishing_model.pkl")
        print("✅ Model loaded successfully")
        
        # Test prediction with sample data
        test_data = pd.DataFrame([[
            50,  # url_length
            1,   # has_https
            0,   # has_http
            0,   # has_at_symbol
            0,   # has_many_dots
            0    # has_suspicious_word
        ]], columns=["url_length", "has_https", "has_http", "has_at_symbol", "has_many_dots", "has_suspicious_word"])
        
        prediction = model.predict(test_data)
        print(f"✅ Sample prediction: {'Phishing' if prediction[0] == 1 else 'Legitimate'}")
        
        return True
        
    except Exception as e:
        print(f"❌ Model loading failed: {e}")
        return False

def test_flask_app_import():
    """Test that the Flask app can be imported."""
    print("\n🌐 Testing Flask app import...")
    
    try:
        from app import app
        print("✅ Flask app imported successfully")
        print("✅ App is ready to run with 'python app.py'")
        return True
    except Exception as e:
        print(f"❌ Flask app import failed: {e}")
        return False

def main():
    """Run all tests."""
    print("🔧 PhishVision System Test Suite (Simple)")
    print("=" * 50)
    
    tests = [
        ("Module Imports", test_imports),
        ("Feature Extraction", test_feature_extraction),
        ("Required Files", test_model_files),
        ("Model Loading", test_model_loading),
        ("Flask App", test_flask_app_import)
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n🧪 Running {test_name} test...")
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ {test_name} test failed with exception: {e}")
            results.append((test_name, False))
    
    print("\n📊 Test Summary:")
    print("=" * 30)
    all_passed = True
    for test_name, passed in results:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"{status} {test_name}")
        if not passed:
            all_passed = False
    
    if all_passed:
        print("\n🎉 All tests passed! Your PhishVision system is ready to use.")
        print("\nTo run the system:")
        print("1. python generate_dataset.py  # (already done)")
        print("2. python train_model.py       # (already done)")
        print("3. python app.py               # Start the Flask API")
    else:
        print("\n⚠️  Some tests failed. Please check the errors above.")
    
    return all_passed

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)