#!/usr/bin/env python3
"""
PhishVision Startup Script
Automatically sets up and runs the PhishVision system.
"""

import os
import sys
import subprocess
import logging
from pathlib import Path

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def run_script(script_name, description):
    """
    Run a Python script with error handling.
    
    Args:
        script_name (str): Name of the script to run
        description (str): Description of what the script does
    """
    print(f"\n🚀 {description}...")
    
    if not os.path.exists(script_name):
        print(f"❌ Error: {script_name} not found")
        return False
    
    try:
        result = subprocess.run([sys.executable, script_name], 
                              capture_output=True, text=True, timeout=60)
        
        if result.returncode == 0:
            print(f"✅ {description} completed successfully")
            if result.stdout:
                print("Output:", result.stdout.strip())
            return True
        else:
            print(f"❌ {description} failed")
            if result.stderr:
                print("Error:", result.stderr.strip())
            return False
            
    except subprocess.TimeoutExpired:
        print(f"❌ {description} timed out")
        return False
    except Exception as e:
        print(f"❌ {description} failed with exception: {e}")
        return False

def check_dependencies():
    """Check if required dependencies are available."""
    print("🔍 Checking dependencies...")
    
    required_packages = ['pandas', 'sklearn', 'joblib', 'flask']
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package} is available")
        except ImportError:
            print(f"❌ {package} is missing")
            missing_packages.append(package)
    
    if missing_packages:
        print(f"\n❌ Missing packages: {missing_packages}")
        print("Please install them using: pip install " + " ".join(missing_packages))
        return False
    
    return True

def main():
    """Main function to run the complete PhishVision setup."""
    print("🔧 PhishVision Automatic Setup")
    print("=" * 50)
    
    # Check dependencies
    if not check_dependencies():
        print("\n❌ Setup failed due to missing dependencies")
        return False
    
    # Step 1: Generate dataset
    if not os.path.exists("phishing_dataset.csv"):
        if not run_script("generate_dataset.py", "Generating dataset"):
            print("\n❌ Setup failed at dataset generation")
            return False
    else:
        print("\n✅ Dataset already exists, skipping generation")
    
    # Step 2: Train model
    if not os.path.exists("phishing_model.pkl"):
        if not run_script("train_model.py", "Training model"):
            print("\n❌ Setup failed at model training")
            return False
    else:
        print("\n✅ Model already exists, skipping training")
    
    # Step 3: Run tests
    if not run_script("simple_test.py", "Running system tests"):
        print("\n⚠️  System tests failed, but continuing...")
    
    # Step 4: Start Flask app
    print("\n🌐 Starting PhishVision API...")
    print("=" * 30)
    print("The API will be available at: http://localhost:5000")
    print("Available endpoints:")
    print("  - GET  /health   - Check service health")
    print("  - POST /predict  - Predict phishing URLs")
    print("  - GET  /features - Get required features")
    print("\nPress Ctrl+C to stop the server")
    print("=" * 30)
    
    try:
        # Run the Flask app
        subprocess.run([sys.executable, "app.py"])
    except KeyboardInterrupt:
        print("\n\n✅ PhishVision API stopped by user")
    except Exception as e:
        print(f"\n❌ Failed to start Flask app: {e}")
        return False
    
    return True

if __name__ == "__main__":
    try:
        success = main()
        if success:
            print("\n✅ PhishVision setup completed successfully!")
        else:
            print("\n❌ PhishVision setup failed")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n👋 Setup interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        sys.exit(1)