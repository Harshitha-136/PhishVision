from flask import Flask, request, jsonify
from flask_cors import CORS
import re
import urllib.parse
import logging
import time

app = Flask(__name__)
CORS(app)  # Enable CORS for all origins

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Phishing detection keywords and patterns
PHISHING_KEYWORDS = [
    'login', 'verify', 'secure', 'account', 'suspended', 'confirm', 'update',
    'validate', 'authenticate', 'paypal', 'amazon', 'microsoft', 'apple',
    'google', 'facebook', 'twitter', 'instagram', 'linkedin', 'netflix',
    'urgent', 'immediate', 'expire', 'limited', 'offer', 'winner', 'prize',
    'congratulations', 'claim', 'free', 'bonus', 'reward', 'gift',
    'banking', 'credit', 'debit', 'card', 'security', 'fraud', 'alert'
]

SUSPICIOUS_PATTERNS = [
    r'[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}',  # IP address
    r'[a-zA-Z0-9-]+\.tk$',  # .tk domain
    r'[a-zA-Z0-9-]+\.ml$',  # .ml domain
    r'[a-zA-Z0-9-]+\.ga$',  # .ga domain
    r'[a-zA-Z0-9-]+\.cf$',  # .cf domain
    r'bit\.ly|tinyurl|short|tiny',  # URL shorteners
    r'[a-zA-Z0-9-]+\.ddns\.net$',  # Dynamic DNS
    r'[a-zA-Z0-9-]+\.duckdns\.org$',  # Duck DNS
]

def analyze_url(url):
    """
    Analyze URL for phishing indicators
    Returns: tuple (is_phishing, confidence_score, reasons)
    """
    try:
        parsed_url = urllib.parse.urlparse(url.lower())
        domain = parsed_url.netloc
        path = parsed_url.path
        query = parsed_url.query
        full_url = url.lower()
        
        phishing_indicators = []
        confidence_score = 0
        
        # Check for suspicious patterns
        for pattern in SUSPICIOUS_PATTERNS:
            if re.search(pattern, full_url):
                phishing_indicators.append(f"Suspicious pattern detected: {pattern}")
                confidence_score += 25
        
        # Check for phishing keywords
        keyword_count = 0
        for keyword in PHISHING_KEYWORDS:
            if keyword in full_url:
                keyword_count += 1
                phishing_indicators.append(f"Phishing keyword detected: {keyword}")
        
        # Increase confidence based on keyword count
        if keyword_count > 0:
            confidence_score += min(keyword_count * 10, 40)
        
        # Check for suspicious domain characteristics
        if len(domain.split('.')) > 4:  # Too many subdomains
            phishing_indicators.append("Suspicious subdomain structure")
            confidence_score += 15
        
        # Check for lookalike domains
        legitimate_domains = ['google', 'facebook', 'microsoft', 'apple', 'amazon', 'paypal', 'netflix']
        for legit_domain in legitimate_domains:
            if legit_domain in domain and not domain.endswith(f'.{legit_domain}.com'):
                phishing_indicators.append(f"Potential lookalike domain for {legit_domain}")
                confidence_score += 30
        
        # Check for suspicious URL length
        if len(url) > 100:
            phishing_indicators.append("Unusually long URL")
            confidence_score += 10
        
        # Check for URL encoding tricks
        if '%' in url and url.count('%') > 3:
            phishing_indicators.append("Excessive URL encoding detected")
            confidence_score += 15
        
        # Determine if it's phishing based on confidence score
        is_phishing = confidence_score >= 30
        
        return is_phishing, confidence_score, phishing_indicators
        
    except Exception as e:
        logger.error(f"Error analyzing URL: {str(e)}")
        return False, 0, ["Error analyzing URL"]

@app.route('/predict', methods=['POST'])
def predict():
    """
    Predict if a URL is phishing
    Expects: {"url": "https://example.com"}
    Returns: {"result": "phishing"|"safe", "confidence": 0-100, "reasons": [...]}
    """
    try:
        data = request.get_json()
        
        if not data or 'url' not in data:
            return jsonify({
                'error': 'Missing URL parameter',
                'result': 'error'
            }), 400
        
        url = data['url'].strip()
        
        # Basic URL validation
        if not url or len(url) < 4:
            return jsonify({
                'error': 'Invalid URL',
                'result': 'error'
            }), 400
        
        logger.info(f"Analyzing URL: {url}")
        
        is_phishing, confidence_score, reasons = analyze_url(url)
        
        result = {
            'result': 'phishing' if is_phishing else 'safe',
            'confidence': confidence_score,
            'reasons': reasons,
            'url': url,
            'timestamp': time.time()
        }
        
        logger.info(f"Analysis result: {result['result']} (confidence: {result['confidence']}%)")
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Error in predict endpoint: {str(e)}")
        return jsonify({
            'error': 'Internal server error',
            'result': 'error',
            'message': str(e)
        }), 500

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'message': 'PhishVision backend is running'
    })

@app.route('/', methods=['GET'])
def index():
    """Root endpoint"""
    return jsonify({
        'message': 'PhishVision Phishing Detection API',
        'version': '1.0',
        'endpoints': {
            '/predict': 'POST - Analyze URL for phishing',
            '/health': 'GET - Health check'
        }
    })

if __name__ == '__main__':
    print("🔍 PhishVision Backend Starting...")
    print("🌐 Server running on http://127.0.0.1:5000")
    print("📡 Ready to analyze URLs for phishing detection")
    app.run(host='127.0.0.1', port=5000, debug=True)
