#!/bin/bash
source venv/bin/activate
python backend/app.py
