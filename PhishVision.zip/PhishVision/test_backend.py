#!/usr/bin/env python3
"""
Test script for PhishVision backend
"""

import requests
import json
import time

BACKEND_URL = 'http://127.0.0.1:5000'

def test_backend():
    print("🔍 Testing PhishVision Backend...")
    print("=" * 50)
    
    # Test 1: Health check
    print("\n1. Testing health endpoint...")
    try:
        response = requests.get(f"{BACKEND_URL}/health", timeout=5)
        if response.status_code == 200:
            print("✅ Health check passed")
            print(f"   Response: {response.json()}")
        else:
            print(f"❌ Health check failed: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ Health check failed: {e}")
        print("💡 Make sure the backend is running: python backend/app.py")
        return False
    
    # Test 2: Safe URL
    print("\n2. Testing safe URL...")
    try:
        test_data = {"url": "https://www.google.com"}
        response = requests.post(f"{BACKEND_URL}/predict", 
                               json=test_data, 
                               timeout=5)
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Safe URL test passed")
            print(f"   URL: {test_data['url']}")
            print(f"   Result: {result['result']}")
            print(f"   Confidence: {result['confidence']}%")
        else:
            print(f"❌ Safe URL test failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Safe URL test failed: {e}")
    
    # Test 3: Suspicious URL (with phishing keywords)
    print("\n3. Testing suspicious URL...")
    try:
        test_data = {"url": "https://secure-login-verification.suspicious-site.com/urgent-account-update"}
        response = requests.post(f"{BACKEND_URL}/predict", 
                               json=test_data, 
                               timeout=5)
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Suspicious URL test passed")
            print(f"   URL: {test_data['url']}")
            print(f"   Result: {result['result']}")
            print(f"   Confidence: {result['confidence']}%")
            print(f"   Reasons: {result['reasons']}")
        else:
            print(f"❌ Suspicious URL test failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Suspicious URL test failed: {e}")
    
    # Test 4: Error handling
    print("\n4. Testing error handling...")
    try:
        response = requests.post(f"{BACKEND_URL}/predict", 
                               json={}, 
                               timeout=5)
        if response.status_code == 400:
            print("✅ Error handling test passed")
            print(f"   Response: {response.json()}")
        else:
            print(f"❌ Error handling test failed: Expected 400, got {response.status_code}")
    except Exception as e:
        print(f"❌ Error handling test failed: {e}")
    
    print("\n" + "=" * 50)
    print("✅ Backend testing completed!")
    print("\n💡 Next steps:")
    print("   1. Load the Chrome extension from the 'extension/' folder")
    print("   2. Make sure the backend is running")
    print("   3. Visit websites to test real-time detection")
    
    return True

if __name__ == "__main__":
    test_backend()