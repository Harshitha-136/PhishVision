// PhishVision Content Script
console.log('🔍 PhishVision Content Script Loaded');

// Function to send URL for analysis
function checkCurrentUrl() {
  const currentUrl = window.location.href;
  
  // Skip checking certain URLs
  if (currentUrl.startsWith('chrome://') || 
      currentUrl.startsWith('chrome-extension://') ||
      currentUrl.startsWith('about:') ||
      currentUrl.startsWith('moz-extension://')) {
    return;
  }
  
  console.log('📤 Sending URL for analysis:', currentUrl);
  
  // Send message to background script
  chrome.runtime.sendMessage({
    type: 'checkUrl',
    url: currentUrl
  }).catch(error => {
    console.error('❌ Error sending message to background:', error);
  });
}

// Check URL when page loads
checkCurrentUrl();

// Also check when URL changes (for SPAs)
let lastUrl = window.location.href;
const observer = new MutationObserver(() => {
  const currentUrl = window.location.href;
  if (currentUrl !== lastUrl) {
    lastUrl = currentUrl;
    console.log('🔄 URL changed, checking again:', currentUrl);
    setTimeout(checkCurrentUrl, 1000); // Delay to ensure page is loaded
  }
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});

// Listen for popstate events (back/forward navigation)
window.addEventListener('popstate', () => {
  setTimeout(checkCurrentUrl, 500);
});

// Listen for pushstate/replacestate (programmatic navigation)
const originalPushState = history.pushState;
const originalReplaceState = history.replaceState;

history.pushState = function() {
  originalPushState.apply(history, arguments);
  setTimeout(checkCurrentUrl, 500);
};

history.replaceState = function() {
  originalReplaceState.apply(history, arguments);
  setTimeout(checkCurrentUrl, 500);
};

console.log('✅ PhishVision Content Script Ready');
