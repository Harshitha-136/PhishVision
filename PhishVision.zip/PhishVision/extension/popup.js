--- extension/popup.js
+++ extension/popup.js
@@ -1,8 +1,173 @@
-// PhishVision Popup Script
console.log('🔍 PhishVision Popup Script Loaded');

const BACKEND_URL = 'http://127.0.0.1:5000';

// DOM elements
let statusText, backendStatus, currentUrl, urlStatus, recentDetections;

document.addEventListener('DOMContentLoaded', async () => {
-  
+// PhishVision Popup Script
+console.log('🔍 PhishVision Popup Script Loaded');
+
+const BACKEND_URL = 'http://127.0.0.1:5000';
+
+// DOM elements
+let statusText, backendStatus, currentUrl, urlStatus, recentDetections;
+
+document.addEventListener('DOMContentLoaded', async () => {
+  // Initialize DOM elements
+  statusText = document.getElementById('status-text');
+  backendStatus = document.getElementById('backend-status');
+  currentUrl = document.getElementById('current-url');
+  urlStatus = document.getElementById('url-status');
+  recentDetections = document.getElementById('recent-detections');
+  
+  // Initialize popup
+  await initializePopup();
+  
+  // Setup event listeners
+  setupEventListeners();
+});
+
+async function initializePopup() {
+  try {
+    // Check backend status
+    await checkBackendStatus();
+    
+    // Get current tab info
+    await getCurrentTabInfo();
+    
+    // Load recent detections
+    await loadRecentDetections();
+    
+  } catch (error) {
+    console.error('❌ Error initializing popup:', error);
+  }
+}
+
+async function checkBackendStatus() {
+  try {
+    const response = await fetch(`${BACKEND_URL}/health`, {
+      method: 'GET',
+      timeout: 5000
     });
+    
+    if (response.ok) {
+      const data = await response.json();
+      backendStatus.textContent = '✅ Backend Connected';
+      backendStatus.className = 'backend-connected';
+    } else {
+      throw new Error('Backend not responding');
+    }
+  } catch (error) {
+    backendStatus.textContent = '❌ Backend Offline';
+    backendStatus.className = 'backend-offline';
+    console.warn('⚠️ Backend not available:', error);
+  }
+}
+
+async function getCurrentTabInfo() {
+  try {
+    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
+    const tab = tabs[0];
+    
+    if (tab && tab.url) {
+      const url = tab.url;
+      currentUrl.textContent = new URL(url).hostname;
+      currentUrl.title = url;
+      
+      // Check if URL is safe to analyze
+      if (url.startsWith('chrome://') || url.startsWith('chrome-extension://')) {
+        urlStatus.textContent = 'System page - not analyzed';
+        urlStatus.className = 'url-system';
+      } else {
+        urlStatus.textContent = 'Monitored for phishing';
+        urlStatus.className = 'url-monitored';
+      }
+    } else {
+      currentUrl.textContent = 'No active tab';
+      urlStatus.textContent = 'N/A';
+    }
+  } catch (error) {
+    console.error('❌ Error getting current tab:', error);
+    currentUrl.textContent = 'Error loading tab';
+    urlStatus.textContent = 'Error';
+  }
+}
+
+async function loadRecentDetections() {
+  try {
+    const storage = await chrome.storage.local.get();
+    const detections = [];
+    
+    // Find recent detections
+    for (const [key, value] of Object.entries(storage)) {
+      if (key.startsWith('detection_')) {
+        detections.push(value);
+      }
+    }
+    
+    // Sort by timestamp (most recent first)
+    detections.sort((a, b) => b.timestamp - a.timestamp);
+    
+    // Display recent detections
+    if (detections.length > 0) {
+      recentDetections.innerHTML = detections.slice(0, 3).map(detection => {
+        const domain = new URL(detection.url).hostname;
+        const time = new Date(detection.timestamp).toLocaleString();
+        return `
+          <div class="detection-item">
+            <div class="detection-domain">${domain}</div>
+            <div class="detection-info">
+              <span class="detection-confidence">${detection.confidence}% confidence</span>
+              <span class="detection-time">${time}</span>
+            </div>
+          </div>
+        `;
+      }).join('');
+    } else {
+      recentDetections.innerHTML = '<p class="no-detections">No recent phishing sites detected</p>';
+    }
+  } catch (error) {
+    console.error('❌ Error loading recent detections:', error);
+    recentDetections.innerHTML = '<p class="no-detections">Error loading detections</p>';
+  }
+}
+
+function setupEventListeners() {
+  // Check current URL button
+  const checkCurrentUrlBtn = document.getElementById('check-current-url');
+  checkCurrentUrlBtn.addEventListener('click', async () => {
+    try {
+      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
+      const tab = tabs[0];
+      
+      if (tab && tab.url) {
+        checkCurrentUrlBtn.textContent = 'Checking...';
+        checkCurrentUrlBtn.disabled = true;
+        
+        // Send message to background script
+        chrome.runtime.sendMessage({
+          type: 'checkUrl',
+          url: tab.url
+        });
+        
+        // Reset button after 2 seconds
+        setTimeout(() => {
+          checkCurrentUrlBtn.textContent = 'Check Current URL';
+          checkCurrentUrlBtn.disabled = false;
+        }, 2000);
+      }
+    } catch (error) {
+      console.error('❌ Error checking current URL:', error);
+    }
   });
+  
+  // Settings button
+  const viewSettingsBtn = document.getElementById('view-settings');
+  viewSettingsBtn.addEventListener('click', () => {
+    // You can implement settings page here
+    chrome.tabs.create({ url: 'chrome://extensions/' });
+  });
+}
+
+// Listen for messages from background script
+chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
+  if (message.type === 'detectionUpdate') {
+    loadRecentDetections();
+  }
 });
+
+console.log('✅ PhishVision Popup Script Ready');