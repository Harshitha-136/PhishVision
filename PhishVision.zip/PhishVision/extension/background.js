// PhishVision Background Script
console.log('🔍 PhishVision Background Script Started');

const BACKEND_URL = 'http://127.0.0.1:5000';

// Storage for checked URLs to avoid duplicate checks
const checkedUrls = new Set();

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('📨 Message received:', message);

  if (message.type === 'checkUrl') {
    handleUrlCheck(message.url, sender.tab)
      .then(result => {
        sendResponse({ success: true, result: result });
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }

  return false;
});

// Handle URL checking
async function handleUrlCheck(url, tab) {
  try {
    if (checkedUrls.has(url)) {
      console.log('🔄 URL already checked recently:', url);
      return { cached: true, url: url };
    }

    checkedUrls.add(url);
    console.log('🔍 Checking URL:', url);

    const response = await fetch(`${BACKEND_URL}/predict`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: url })
    });

    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

    const data = await response.json();
    console.log('📊 Analysis result:', data);

    if (data.result === 'phishing') {
      await showPhishingAlert(url, data, tab);

      try {
        await chrome.storage.local.set({
          [`detection_${Date.now()}`]: {
            url: url,
            timestamp: Date.now(),
            confidence: data.confidence,
            reasons: data.reasons
          }
        });
      } catch (storageError) {
        console.warn('⚠️ Could not save detection to storage:', storageError);
      }

      return { detected: true, data: data };
    } else {
      console.log('✅ URL is safe:', url);

      if (tab && tab.id) {
        try {
          await chrome.action.setBadgeText({ text: '', tabId: tab.id });
        } catch (badgeError) {
          console.warn('⚠️ Could not clear badge:', badgeError);
        }
      }

      return { detected: false, data: data };
    }

  } catch (error) {
    console.error('❌ Error checking URL:', error);

    if (error.message.includes('Failed to fetch') || error.message.includes('NetworkError')) {
      console.warn('⚠️ Backend not available. Make sure Flask server is running on http://127.0.0.1:5000');
    }

    throw error;
  }
}

// Show phishing alert notification with voice alert
async function showPhishingAlert(url, data, tab) {
  try {
    const domain = new URL(url).hostname;
    const notificationId = `phishing_${Date.now()}`;

    await chrome.notifications.create(notificationId, {
      type: 'basic',
      iconUrl: 'icon.png',
      title: 'PhishVision Alert!',
      message: `Phishing detected on ${domain} (${data.confidence}% confidence). Be extremely cautious!`,
      priority: 2,
      requireInteraction: true
    });

    console.log('🚨 Phishing alert shown for:', url);

    if (tab && tab.id) {
      try {
        await chrome.action.setBadgeText({ text: '!', tabId: tab.id });
        await chrome.action.setBadgeBackgroundColor({ color: '#ff4444', tabId: tab.id });
      } catch (badgeError) {
        console.warn('⚠️ Could not set badge:', badgeError);
      }

      // Voice Alert: Inject into tab
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const msg = new SpeechSynthesisUtterance("Warning! This site may be a phishing attempt.");
          msg.lang = 'en-US'; // Change to 'hi-IN' or 'ta-IN' if needed
          msg.pitch = 1;
          msg.rate = 1;
          window.speechSynthesis.speak(msg);
        }
      });
    }

    setTimeout(() => {
      chrome.notifications.clear(notificationId);
    }, 10000);

  } catch (error) {
    console.error('❌ Error showing alert:', error);
  }
}

// Clean up checked URLs every 5 mins
setInterval(() => {
  checkedUrls.clear();
  console.log('🧹 Cleared checked URLs cache');
}, 5 * 60 * 1000);

// On install
chrome.runtime.onInstalled.addListener(() => {
  console.log('🎉 PhishVision Extension Installed');

  fetch(`${BACKEND_URL}/health`)
    .then(response => {
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return response.json();
    })
    .then(data => {
      console.log('✅ Backend connection successful:', data);
    })
    .catch(error => {
      console.warn('⚠️ Backend not available:', error);
      console.log('💡 Make sure to run: python backend/app.py');

      chrome.notifications.create('install_notification', {
        type: 'basic',
        iconUrl: 'icon.png',
        title: 'PhishVision Installed',
        message: 'Please start the backend server to enable protection.',
        priority: 1
      });
    });
});

// Handle notification clicks
chrome.notifications.onClicked.addListener((notificationId) => {
  console.log('🔔 Notification clicked:', notificationId);
  chrome.notifications.clear(notificationId);

  if (notificationId === 'install_notification') {
    chrome.tabs.create({ url: 'https://github.com/yourusername/PhishVision' });
  }
});

// Clear badge on page change
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    setTimeout(() => {
      chrome.action.setBadgeText({ text: '', tabId: tabId });
    }, 30000);
  }
});

// Periodic cleanup: keep only latest 100 detections
setInterval(async () => {
  try {
    const storage = await chrome.storage.local.get();
    const detectionKeys = Object.keys(storage).filter(key => key.startsWith('detection_'));

    if (detectionKeys.length > 100) {
      const sortedKeys = detectionKeys.sort((a, b) => {
        return storage[b].timestamp - storage[a].timestamp;
      });

      const keysToRemove = sortedKeys.slice(100);
      for (const key of keysToRemove) {
        await chrome.storage.local.remove(key);
      }

      console.log(`🧹 Cleaned up ${keysToRemove.length} old detections`);
    }
  } catch (error) {
    console.warn('⚠️ Could not clean up old detections:', error);
  }
}, 60 * 60 * 1000); // Every hour
